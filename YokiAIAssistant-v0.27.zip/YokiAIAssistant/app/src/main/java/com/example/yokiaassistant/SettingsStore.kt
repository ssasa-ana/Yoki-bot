package com.example.yokiaassistant

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * All user settings in one place.
 * The API key is stored in EncryptedSharedPreferences when possible,
 * with a plain SharedPreferences fallback so the app still works on
 * devices where encrypted prefs fail (old Vivo / Android 11 quirks).
 */
object SettingsStore {
    private const val PREFS = "yoki_settings"
    private const val SECURE_PREFS = "yoki_secure"

    const val KEY_MONITOR = "monitor_enabled"
    const val KEY_MODE = "reply_mode" // manual | auto | off
    const val KEY_PROVIDER = "ai_provider" // gemini | openai
    const val KEY_API_KEY = "api_key"
    const val KEY_MODEL = "ai_model"
    const val KEY_BASE_URL = "openai_base_url"
    const val KEY_SYSTEM_PROMPT = "system_prompt"
    const val KEY_FALLBACK = "reply_text"
    const val KEY_USE_FALLBACK = "use_fallback"
    const val KEY_MY_ON_LEFT = "my_messages_on_left"
    const val KEY_COOLDOWN = "cooldown_seconds"
    const val KEY_MAX_PER_HOUR = "max_per_hour"
    const val KEY_PENDING_REPLY = "pending_reply_text"
    const val KEY_PENDING_HASH = "pending_reply_hash"
    const val KEY_LAST_SENT = "last_sent_text"
    const val KEY_AUTO_OPEN_NOTIF = "auto_open_notifications"
    const val KEY_CUSTOM_REPLIES = "custom_replies_text"
    const val KEY_CUSTOM_REPLY_INDEX = "custom_reply_index"
    const val KEY_DRAFT_MODE = "draft_mode"
    const val KEY_KEYWORD_RULES = "keyword_rules"

    // v0.4 — الشفافية إجبارية: كل رد يتبعت لازم يبدأ بالسطر ده، ومفيش إعداد يلغيها.
    const val BOT_PREFIX = "🤖 رد تلقائي من بوت \u2014 صاحب الحساب مش موجود دلوقتي:\n"

    // v0.9: سطر البوت اتشال بناءً على طلب المستخدم — الرد بيتبعت زي ما هو.
    fun ensureTransparent(text: String): String = text.trim()

    fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun securePrefs(context: Context): SharedPreferences? {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context, SECURE_PREFS, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            null
        }
    }

    fun getApiKey(context: Context): String {
        val secure = securePrefs(context)?.getString(KEY_API_KEY, null)
        if (!secure.isNullOrBlank()) return secure
        return prefs(context).getString(KEY_API_KEY, "") ?: ""
    }

    fun setApiKey(context: Context, value: String) {
        val secure = securePrefs(context)
        if (secure != null) {
            secure.edit().putString(KEY_API_KEY, value).apply()
            prefs(context).edit().remove(KEY_API_KEY).apply()
        } else {
            prefs(context).edit().putString(KEY_API_KEY, value).apply()
        }
    }

    // v0.7 — custom replies the user writes himself, one per line, up to 50.
    // The bot cycles through them in order instead of calling the AI.
    fun customRepliesText(context: Context): String =
        prefs(context).getString(KEY_CUSTOM_REPLIES, "") ?: ""

    fun customReplies(context: Context): List<String> =
        customRepliesText(context).lines().map { it.trim() }.filter { it.isNotEmpty() }.take(50)

    fun customReplyIndex(context: Context): Int =
        prefs(context).getInt(KEY_CUSTOM_REPLY_INDEX, 0)

    // v0.8 — وضع المسودة: البوت يكتب الرد في خانة الكتابة بس، وانت تدوس
    // إرسال بنفسك. الافتراضي مطفي (الإرسال التلقائي زي قبل كده).
    fun draftMode(context: Context) =
        prefs(context).getBoolean(KEY_DRAFT_MODE, false)

    // v0.11 — ردود بالكلمات المفتاحية: كل سطر "كلمة1،كلمة2=الرد".
    // لو رسالة الطرف التاني فيها أي كلمة من السطر، يتبعت الرد ده (له الأولوية
    // على الردود المخصصة وعلى الذكاء الاصطناعي).
    fun keywordRulesText(context: Context): String =
        prefs(context).getString(KEY_KEYWORD_RULES, "") ?: ""

    private fun stripInvisible(s: String): String =
        s.replace(Regex("[\\u200B-\\u200F\\u202A-\\u202E\\u2066-\\u2069\\uFEFF]"), "")

    private fun normalizeAr(s: String): String =
        stripInvisible(s).lowercase()
            .replace(Regex("[\\u064B-\\u0652\\u0640]"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ة', 'ه').replace('ى', 'ي')
            // v0.27: punctuation does not matter ("من وين؟ من مصر" == "من وين من مصر").
            .replace(Regex("[\\p{Punct}\\u061F\\u060C\\u061B\\u2026~]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    /** Number of usable rules saved (for the log). */
    fun keywordRulesCount(context: Context): Int =
        keywordRulesText(context).lines().count { line ->
            val i = stripInvisible(line).indexOfAny(charArrayOf('=', '＝', ':', '：'))
            i > 0
        }

    fun matchKeywordReply(context: Context, incoming: String): String? {
        val msg = normalizeAr(incoming)
        // v0.26: the MOST SPECIFIC rule wins (longest matching keyword), not the first
        // one — so "من وين من مصر" beats "من وين" whatever their order in the list.
        var best: String? = null
        var bestLen = -1
        for (rawLine in keywordRulesText(context).lines()) {
            val line = stripInvisible(rawLine)
            val i = line.indexOfAny(charArrayOf('=', '＝', ':', '：'))
            if (i <= 0) continue
            val keys = line.substring(0, i).split(',', '،')
                .map { normalizeAr(it.trim()) }
                .filter { it.isNotEmpty() }
            val reply = line.substring(i + 1).trim()
            if (reply.isEmpty()) continue
            for (k in keys) {
                if (msg.contains(k) && k.length > bestLen) {
                    best = reply
                    bestLen = k.length
                }
            }
        }
        return best
    }

    fun nextCustomReply(context: Context): String? {
        val list = customReplies(context)
        if (list.isEmpty()) return null
        val idx = customReplyIndex(context) % list.size
        val reply = list[idx]
        prefs(context).edit().putInt(KEY_CUSTOM_REPLY_INDEX, (idx + 1) % list.size).apply()
        return reply
    }

    fun isMonitorEnabled(context: Context) =
        prefs(context).getBoolean(KEY_MONITOR, false)

    // v0.6 — experimental, user explicitly asked: open a private-message
    // notification automatically so the bot can reply without the chat
    // already being open. Default true, as requested.
    fun autoOpenNotifications(context: Context) =
        prefs(context).getBoolean(KEY_AUTO_OPEN_NOTIF, true)

    fun replyMode(context: Context): String =
        prefs(context).getString(KEY_MODE, "auto") ?: "auto"

    fun provider(context: Context): String =
        prefs(context).getString(KEY_PROVIDER, "gemini") ?: "gemini"

    fun model(context: Context): String {
        val saved = prefs(context).getString(KEY_MODEL, "") ?: ""
        if (saved.isNotBlank()) return saved
        return if (provider(context) == "openai") "gpt-4o-mini" else "gemini-2.0-flash"
    }

    fun baseUrl(context: Context): String =
        prefs(context).getString(KEY_BASE_URL, "https://api.openai.com/v1") ?: "https://api.openai.com/v1"

    fun systemPrompt(context: Context): String {
        val saved = prefs(context).getString(KEY_SYSTEM_PROMPT, "") ?: ""
        // v0.4 migration: the v0.3 default pretended to be the owner — never reuse it.
        if (saved == "أنت مساعد ودود ومختصر. رد بالعربية بنفس أسلوب المحادثة، في سطر أو سطرين فقط، بدون شرح وبدون علامات تنصيص حول الرد.") return "أنت بوت مساعد شفاف في Yoki. لا تتظاهر أبداً أنك صاحب الحساب ولا تتكلم بصيغة المتكلم عنه. رد بالعربية باختصار في سطر أو سطرين بصيغة البوت، وقل إن صاحب الحساب مش موجود وهيرجع يرد بنفسه."
        if (saved.isNotBlank()) return saved
        return "أنت بوت مساعد شفاف في Yoki. لا تتظاهر أبداً أنك صاحب الحساب ولا تتكلم بصيغة المتكلم عنه. رد بالعربية باختصار في سطر أو سطرين بصيغة البوت، وقل إن صاحب الحساب مش موجود وهيرجع يرد بنفسه."
    }

    fun fallbackReply(context: Context): String {
        val saved = prefs(context).getString(KEY_FALLBACK, "") ?: ""
        // v0.4 migration: the v0.3 fallback "أهلاً! 😊" had no disclosure.
        if (saved.isBlank() || saved == "أهلاً! 😊") return "أهلاً بيك! صاحب الحساب مش موجود دلوقتي، وهيرجع يرد عليك بنفسه قريب."
        return saved
    }

    fun useFallback(context: Context) =
        prefs(context).getBoolean(KEY_USE_FALLBACK, false)

    fun myMessagesOnLeft(context: Context) =
        prefs(context).getBoolean(KEY_MY_ON_LEFT, true) // v0.4: from his video, own Yoki bubbles are purple on the LEFT

    fun cooldownSeconds(context: Context): Int =
        prefs(context).getInt(KEY_COOLDOWN, 5).coerceIn(5, 600)

    fun maxPerHour(context: Context): Int =
        prefs(context).getInt(KEY_MAX_PER_HOUR, 20).coerceIn(1, 200)
}

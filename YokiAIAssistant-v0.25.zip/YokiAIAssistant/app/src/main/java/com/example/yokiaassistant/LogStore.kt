package com.example.yokiaassistant

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Local-only log. Logcat gets metadata only (no chat text),
 * the full preview lives in an internal file the user can view
 * and clear from MainActivity. Nothing is uploaded anywhere.
 */
object LogStore {
    private const val FILE_NAME = "yoki_log.txt"
    private const val MAX_LINES = 200

    fun append(context: Context, message: String) {
        try {
            val stamp = SimpleDateFormat("HH:mm:ss", Locale("ar", "EG")).format(Date())
            val file = File(context.filesDir, FILE_NAME)
            val lines = if (file.exists()) file.readLines().toMutableList() else mutableListOf()
            lines.add("[$stamp] $message")
            while (lines.size > MAX_LINES) lines.removeAt(0)
            file.writeText(lines.joinToString("\n"))
        } catch (e: Exception) {
            Log.w("YokiAssistant", "log write failed", e)
        }
        // Logcat: metadata only, never chat content.
        Log.d("YokiAssistant", message.take(120))
    }

    fun readLast(context: Context, count: Int = 40): String {
        return try {
            val file = File(context.filesDir, FILE_NAME)
            if (!file.exists()) return "لا توجد أحداث بعد."
            file.readLines().takeLast(count).joinToString("\n")
        } catch (e: Exception) {
            "تعذر قراءة السجل."
        }
    }

    fun clear(context: Context) {
        try { File(context.filesDir, FILE_NAME).delete() } catch (e: Exception) { /* ignore */ }
    }
}

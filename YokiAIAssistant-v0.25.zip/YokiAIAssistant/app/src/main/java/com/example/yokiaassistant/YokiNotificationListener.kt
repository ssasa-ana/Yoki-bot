package com.example.yokiaassistant

import android.app.Notification
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * v0.6 — experimental notification auto-open, user explicitly requested:
 * when a Yoki private-message notification arrives, open that chat so
 * the accessibility service can reply as usual. Only fires when
 * monitoring is ON, mode is auto, and the auto-open toggle is ON.
 * Room/group/call notifications are ignored. If unsure, it opens
 * anyway — the accessibility service only replies inside an open
 * 1-to-1 chat, so a wrong open is harmless.
 * Requires the user to grant Notification access in system settings
 * (MainActivity has a button for that screen).
 */
class YokiNotificationListener : NotificationListenerService() {

    companion object {
        private const val YOKI_PACKAGE = "com.partyjoy.yoki"
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lastKey: String? = null
    private var lastAt: Long = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName != YOKI_PACKAGE) return
        if (!SettingsStore.isMonitorEnabled(this)) return
        if (SettingsStore.replyMode(this) != "auto") return
        if (!SettingsStore.autoOpenNotifications(this)) return
        // Same notification re-posted (e.g. an update) — open once only.
        val now = System.currentTimeMillis()
        if (sbn.key == lastKey && now - lastAt < 10_000L) return

        val extras = sbn.notification.extras
        val title = extras.getString(Notification.EXTRA_TITLE).orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val combined = "$title $text"
        val notPrivate = listOf("غرفة", "روم", "مكالمة", "اتصال", "group", "room", "call")
            .any { combined.contains(it, ignoreCase = true) }
        if (notPrivate) {
            LogStore.append(this, "تم تجاهل إشعار (ليست رسالة خاصة): ${title.take(60)}")
            return
        }
        lastKey = sbn.key
        lastAt = now
        LogStore.append(this, "إشعار خاص وصل، فتح المحادثة: ${title.take(60)}")
        try {
            sbn.notification.contentIntent?.send()
        } catch (e: Exception) {
            LogStore.append(this, "تعذر فتح الإشعار: ${e.message}")
            return
        }
        // v0.9: let the accessibility service return to the list after replying.
        YokiAccessibilityService.instance?.noteOpenedFromNotification()
        // ~2s for Yoki to open the chat; the accessibility service then
        // sees the new message and replies as usual.
        handler.postDelayed({
            LogStore.append(this, "المحادثة مفتوحة من الإشعار — بانتظار الرد التلقائي")
        }, 2000)
    }
}

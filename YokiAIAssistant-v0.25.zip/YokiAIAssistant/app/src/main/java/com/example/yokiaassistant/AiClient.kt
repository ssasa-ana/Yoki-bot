package com.example.yokiaassistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Minimal AI client, no extra JSON library (org.json is built in).
 * Gemini: POST .../v1beta/models/{model}:generateContent?key=...
 * OpenAI-compatible: POST {baseUrl}/chat/completions with Bearer key.
 * Runs on Dispatchers.IO with a 30s timeout. Returns null on any failure
 * so the caller can fall back or stay silent instead of sending garbage.
 */
object AiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun generateReply(
        context: Context,
        history: List<String>,
        incoming: String
    ): String? = withContext(Dispatchers.IO) {
        val apiKey = SettingsStore.getApiKey(context)
        if (apiKey.isBlank()) return@withContext null
        val system = SettingsStore.systemPrompt(context)
        val prompt = buildString {
            append(system)
            append("\n\nآخر رسائل المحادثة:\n")
            history.takeLast(5).forEach { append("- ").append(it).append("\n") }
            append("\nآخر رسالة واردة: ").append(incoming)
            append("\n\nاكتب رداً قصيراً بصيغة البوت في سطر أو سطرين فقط، بدون شرح، ولا تتظاهر أنك صاحب الحساب.")
        }
        try {
            val raw = if (SettingsStore.provider(context) == "openai") {
                callOpenAi(apiKey, SettingsStore.model(context), SettingsStore.baseUrl(context), system, prompt)
            } else {
                callGemini(apiKey, SettingsStore.model(context), prompt)
            }
            raw?.trim()?.trim('"', ' ', '\n')?.takeIf { it.isNotBlank() && it.length <= 500 }
        } catch (e: Exception) {
            null
        }
    }

    private fun callGemini(apiKey: String, model: String, prompt: String): String? {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 200)
            })
        }.toString()
        val request = Request.Builder().url(url)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val json = JSONObject(response.body?.string() ?: return null)
            return json.optJSONArray("candidates")
                ?.optJSONObject(0)?.optJSONObject("content")
                ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
        }
    }

    private fun callOpenAi(apiKey: String, model: String, baseUrl: String, system: String, prompt: String): String? {
        val url = baseUrl.trimEnd('/') + "/chat/completions"
        val body = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", system))
                put(JSONObject().put("role", "user").put("content", prompt))
            })
            put("temperature", 0.7)
            put("max_tokens", 200)
        }.toString()
        val request = Request.Builder().url(url)
            .header("Authorization", "Bearer $apiKey")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val json = JSONObject(response.body?.string() ?: return null)
            return json.optJSONArray("choices")
                ?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
        }
    }
}

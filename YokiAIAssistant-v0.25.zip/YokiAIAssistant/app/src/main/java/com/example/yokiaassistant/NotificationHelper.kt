package com.example.yokiaassistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationHelper {
    const val CHANNEL_ID = "yoki_reply"
    const val NOTIFICATION_ID = 1001

    fun showApprovalNotification(context: Context, incomingPreview: String, reply: String) {
        createChannel(context)
        val sendIntent = Intent(context, ReplyActionReceiver::class.java).apply {
            action = ReplyActionReceiver.ACTION_SEND
        }
        val dismissIntent = Intent(context, ReplyActionReceiver::class.java).apply {
            action = ReplyActionReceiver.ACTION_DISMISS
        }
        val sendPending = PendingIntent.getBroadcast(
            context, 1, sendIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val dismissPending = PendingIntent.getBroadcast(
            context, 2, dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle("Yoki: رد مقترح")
            .setContentText(reply)
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("وصلت: ${incomingPreview.take(120)}\n\nالرد المقترح: $reply"))
            .addAction(android.R.drawable.ic_menu_send, "إرسال", sendPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "تجاهل", dismissPending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            LogStore.append(context, "تعذر عرض إشعار الموافقة: إذن الإشعارات غير ممنوح")
        }
    }

    fun cancelApproval(context: Context) {
        NotificationManagerCompat.from(context).cancel(NOTIFICATION_ID)
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "اقتراحات الرد", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "إشعار بالرد المقترح قبل إرساله" }
            context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }
}

package com.example.yokiaassistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Handles the notification actions in manual mode.
 * "Send" only sends the exact reply the user already saw in the
 * notification — it never generates a new reply on its own.
 */
class ReplyActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_SEND = "com.example.yokiaassistant.ACTION_SEND_APPROVED"
        const val ACTION_DISMISS = "com.example.yokiaassistant.ACTION_DISMISS_APPROVED"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val prefs = SettingsStore.prefs(context)
        when (intent.action) {
            ACTION_SEND -> {
                val reply = prefs.getString(SettingsStore.KEY_PENDING_REPLY, null)
                val hash = prefs.getInt(SettingsStore.KEY_PENDING_HASH, 0)
                if (reply.isNullOrBlank()) {
                    Toast.makeText(context, "لا يوجد رد معلّق", Toast.LENGTH_SHORT).show()
                    return
                }
                val service = YokiAccessibilityService.instance
                if (service != null) {
                    service.sendApprovedReply(reply, hash)
                    Toast.makeText(context, "جارٍ إرسال الرد…", Toast.LENGTH_SHORT).show()
                } else {
                    // Service is not running right now; keep the reply pending
                    // and tell the user to open Yoki first.
                    Toast.makeText(context, "افتح Yoki أولاً ثم وافق على الإرسال", Toast.LENGTH_LONG).show()
                }
                NotificationHelper.cancelApproval(context)
            }
            ACTION_DISMISS -> {
                prefs.edit()
                    .remove(SettingsStore.KEY_PENDING_REPLY)
                    .remove(SettingsStore.KEY_PENDING_HASH)
                    .apply()
                NotificationHelper.cancelApproval(context)
                LogStore.append(context, "تم تجاهل الرد المقترح من الإشعار")
            }
        }
    }
}

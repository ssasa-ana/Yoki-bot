# Keep the accessibility service and receivers (referenced from the manifest).
-keep public class com.example.yokiaassistant.YokiAccessibilityService
-keep public class com.example.yokiaassistant.ReplyActionReceiver

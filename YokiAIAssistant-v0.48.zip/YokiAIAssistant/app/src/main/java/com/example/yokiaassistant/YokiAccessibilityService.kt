package com.example.yokiaassistant

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * v0.28 — الذكاء: الموديل الافتراضي gemini-flash-latest (2.0 اتقفل)، مع تجربة بديل لو الموديل اتشال،
 *   وحد الرد 1024 توكن، ورسالة الخطأ الحقيقية في السجل.
 * v0.27 — علامات الترقيم (؟ ! ، .) بتتجاهل في مطابقة الكلمات المفتاحية.
 * v0.26 — لو أكتر من قاعدة اتطابقت، بتتاخد القاعدة الأطول كلمة (الأدق) مش الأولى.
 * v0.25 — كارت "فتح الدردشة الصوتية / اتصل الآن" بيتجاهل (الزرار كان ممكن يتحسب رسالتي).
 * v0.24 — بيتابع بس فقاعات الدردشة الحقيقية: بتاعتي (الجنب بتاعي) وبتاعة الشخص
 *   (البيضا على الجنب التاني). أي نص عريض بعرض الشاشة (رسايل Yoki الآلية) بيتجاهل بالشكل.
 * v0.23 — رسايل Yoki الآلية بتاعة مستوى العلاقة ("مبروك! … مستوى علاقتك") بتتجاهل
 *   (كان بيرد عليها بدل رسالة الشخص اللي قبلها).
 * v0.22 — رسالتي لو كانت نص مخفية تحت خانة الكتابة كانت بتتجاهل، فالبوت كان بيرد
 *   على نفس رسالته تاني. دلوقتي بيحكم بأعلى الفقاعة، وفي حماية من الرد المكرر.
 * v0.21 — السجل بيكتب النص اللي قرأه وعدد القواعد المحفوظة لما مفيش تطابق (للتشخيص).
 * v0.20 — الرد بكلمة مفتاحية بيتبعت فوراً من غير ما يستنى الفاصل بين الردود.
 * v0.19 — نفس الكلمة لو اتكررت بيرد عليها تاني بعد 10 ثواني بس (كانت دقيقتين).
 * v0.18 — تسريع: انتظار أقل في كل خطوة (فحص الشاشة 0.3 ثانية بدل 0.8،
 *   الرجوع بعد الإرسال 0.9 ثانية بدل 1.8، فاصل فتح المحادثات 3 ثواني بدل 6).
 * v0.17 — لو الطرف التاني كتب نفس الكلمة اللي أنا رديت بيها قبل كده (مثلاً
 *   "هلا")، كان بيتجاهلها. دلوقتي المقارنة دي بتتطبق بس لو مكان الفقاعة في
 *   النص (مش واضح صاحبها).
 * v0.16 — إصلاح: آخر رسالة قريبة من خانة الكتابة كانت بتتجاهل (فيرد البوت
 *   على رسالة قديمة من عنده ويعتبرها رسالته). دلوقتي بيفرق بين صف اقتراحات
 *   الرد السريع (نصين أو أكتر في نفس الارتفاع) والرسالة الحقيقية. وبيتجاهل
 *   عدادات "x36". ولو المحادثة آخرها رسالتي، مبيفتحهاش تاني لمدة دقيقتين.
 * v0.13 — صفوف "[اربح الألماس]" بتتفتح وبيتردّ عليها حتى من غير رقم أحمر
 *   (وبتتكرر كل 15 ثانية لحد ما تختفي)، ونافذة "الرد الآن" بيتدوس عليها.
 *   الكلمات المفتاحية بتتجاهل علامات الاتجاه الخفية وبتقبل : أو = كفاصل.
 * v0.11 — إصلاحات من سجل التجربة:
 * - رسائل Yoki الآلية ("مبروك على وصولك…", "أنت وهو زوجان…") بتتجاهل
 *   في القائمة وفي المحادثة، فمايفتحهاش ولا يرد عليها.
 * - فحص دوري للقائمة (كل 2-3 ثواني أثناء الانتظار) بدل ما يستنى حدث
 *   في الشاشة، فمفيش تأخير بعد انتهاء فاصل الرد.
 * - ReplyStore: منع تكرار نفس النص بقى لمدة دقيقتين بس (قبل كده كان
 *   بيمنع الرد على أي حد بعت نفس الكلمة "هاي" بعد الأول).
 * - الفاصل الافتراضي بين الردود 8 ثواني بدل 20.
 * v0.9 — مراقبة صفحة الرسائل:
 * - لو واقف على صفحة "الرسائل" وفي محادثة عليها رقم غير مقروء (دايرة
 *   حمرا)، الخدمة تدخلها، ترد بنفس المنطق، وبعد الإرسال ترجع للقائمة
 *   وتستنى الرسالة الجاية. بتشتغل مع مفتاح "فتح المحادثات تلقائياً"،
 *   ووضع الرد "auto"، ووضع المسودة مطفي.
 * - كل صف بيتعالج مرة واحدة (بصمة النص + الرقم)، فلو الرقم/الرسالة
 *   اتغيرت بس يتفتح تاني. وفي مؤقت أمان (15 ثانية) يرجّعك للقائمة لو
 *   المحادثة ماتردش عليها.
 * - سطر "رد تلقائي من بوت" اتشال من الرد.
 * v0.8 — وضع المسودة (Draft mode):
 * - لما المفتاح شغال، البوت يكتب الرد في خانة الكتابة بس (ACTION_SET_TEXT
 *   مع بديل اللصق) وميدوسش زر الإرسال خالص، وانت تدوس إرسال بنفسك لما
 *   ترجع — دي حالة المستخدم بالظبط: يروح يعمل شاي دقيقة ويرجع يلاقي
 *   الكلام جاهز في الخانة. عشان كده زر الإرسال مش مطلوب في الوضع ده.
 * - في وضع المسودة مفيش BOT_PREFIX: انت اللي بتبعت بنفسك بعد ما تراجع
 *   المسودة، فالرسالة منك مش من البوت. في الوضع التلقائي العادي (المسودة
 *   مطفية) سطر البوت الشفاف لسه إجباري على كل رد بيتبعت لوحده.
 * - المسودة بتتجهز مرة واحدة لكل رسالة واردة (نفس حماية ReplyStore:
 *   فاصل 20 ثانية وحد 20 في الساعة)، ولو وصلت رسالة جديدة والمسودة
 *   القديمة لسه مستنية، بتتبدل بالرد الجديد وبيتكتب "تم تحديث المسودة".
 * v0.7 — custom replies + quick-reply-chip fix:
 * - If the user wrote custom replies (one per line, up to 50), the bot
 *   uses the next one in order INSTEAD of the AI, still wrapped with
 *   BOT_PREFIX (disclosure is never removed).
 * - Yoki quick-reply chips ("هاي", "تعرف", "ممكن نتعرف...") sit just
 *   above the input bar and were mistaken for the last message, so the
 *   bot saw "تعرف" and said يرد=لا. They are now ignored by exact text
 *   and by being within ~80dp above the input top.
 * v0.6 — transparent bot:
 * - Send-button precision: the v0.5 position fallback picked the emoji
 *   button in Yoki (it also lives in the input bar) and opened the emoji
 *   panel. v0.6 only accepts an icon IMMEDIATELY adjacent to the input
 *   (within ~48dp of its edge, roughly square 24-64dp), preferring the
 *   icon to the LEFT of the input (RTL send arrow), and explicitly
 *   excludes emoji/sticker/call/gift/image/mic icons.
 * - Emoji panel is closed with BACK after a successful send if it is open.
 * - System promo bubbles ("انضم إلى Yoki", "{image}هو صديق جديد…")
 *   are never replied to.
 * - Notification auto-open lives in YokiNotificationListener.kt.
 * Everything else is v0.5/v0.4: BOT_PREFIX forced, auto default,
 * myMessagesOnLeft default true, cooldown 20s, max 20/hour.
 *
 * v0.5 — transparent bot, send-button fix:
 * In the real Yoki chat the send control is a pink/purple arrow ImageView
 * on the LEFT of the bottom input bar (RTL), with NO "send" / "إرسال"
 * text or id. v0.4 only matched id/label, so it never found the button
 * and processChatIfNeeded() returned early with no log at all.
 * v0.5 keeps the id/label match first, then falls back to POSITION:
 * any clickable image icon in the same vertical band as the editable
 * input (within ~60dp above/below it), preferring one to the left of
 * the input (the RTL send arrow). The same fallback is used after
 * typing, when the arrow appears.
 * v0.5 also logs a short diagnostic line (deduped) on every run, so
 * the next test shows WHY it did or did not reply.
 * Everything else is v0.4: BOT_PREFIX forced on every reply, auto mode
 * default, myMessagesOnLeft default true (own bubbles are purple on
 * the LEFT in Yoki), cooldown 20s, max 20/hour.
 */
class YokiAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: YokiAccessibilityService? = null
            private set
        private const val YOKI_PACKAGE = "com.partyjoy.yoki"
        private const val DEBOUNCE_MS = 300L
    }

    private val scope = CoroutineScope(Dispatchers.IO)
    private val handler = Handler(Looper.getMainLooper())
    private var pendingCheck: Runnable? = null
    private var isProcessing = false
    private var lastDiag = ""
    // v0.8: hash الرسالة اللي مسودتها مستنية دلوقتي في خانة الكتابة.
    // بيمنع إعادة الكتابة فوق مسودة المستخدم بيعدّلها، وبيكشف لما تيجي
    // رسالة جديدة فتتبدل المسودة بالرد الجديد.
    private var pendingDraftHash: Int? = null
    // v0.9: فتح المحادثات تلقائياً من صفحة الرسائل / من الإشعار.
    private var openedFromList = false
    private var lastListClickAt = 0L
    private val handledListSigs = mutableMapOf<String, Long>()
    private var lastPopupAt = 0L
    // v0.22: do not answer the same message twice while no new bubble has appeared.
    private var lastReplyText: String? = null
    private var lastReplyAt = 0L
    private var lastReplyBubbleCount = 0
    private var currentRowSig: String? = null
    private var watchdog: Runnable? = null

    private data class Bubble(
        val text: String,
        val viewId: String,
        val centerX: Float,
        val bottom: Int,
        val top: Int,
        val left: Int,
        val right: Int,
        val className: String
    )

    private data class SendCandidate(
        val node: AccessibilityNodeInfo,
        val text: String,
        val viewId: String,
        val desc: String,
        val centerX: Int,
        val centerY: Int,
        val width: Int,
        val height: Int,
        val className: String
    )

    /** Icons that must NEVER be treated as the send button. */
    private val EXCLUDED_ICON_WORDS = listOf(
        "emoji", "emoticon", "smiley", "sticker",
        "ملصق", "ابتسامة", "إيموجي", "ايموجي",
        "call", "gift", "image", "mic",
        "هاتف", "هدية", "صورة", "ميكروفون",
        "phone", "camera", "voice", "micr"
    )

    private fun isExcludedIcon(viewId: String, text: String, desc: String): Boolean {
        val hay = (viewId + " " + text + " " + desc).lowercase()
        return EXCLUDED_ICON_WORDS.any { hay.contains(it) }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        LogStore.append(this, "خدمة الوصول متصلة")
        // v0.39: if the app ever crashes (which kills the accessibility service), write the
        // reason into the log so it can be read after the restart.
        val appCtx = applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val where = e.stackTrace.firstOrNull { it.className.contains("yokiaassistant") }
                LogStore.append(appCtx, "انهيار التطبيق: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(100)} @ ${where?.fileName}:${where?.lineNumber}")
            } catch (_: Throwable) {
            }
            prev?.uncaughtException(t, e)
        }
        updateKeepAwake()
    }

    override fun onDestroy() {
        instance = null
        setKeepAwake(false)
        super.onDestroy()
    }

    // v0.33: keep the screen on while monitoring (a 1px invisible accessibility overlay
    // with FLAG_KEEP_SCREEN_ON — needs no extra permission), so the phone does not lock.
    private var keepAwakeView: View? = null

    private fun updateKeepAwake() {
        setKeepAwake(SettingsStore.isMonitorEnabled(this) && SettingsStore.replyMode(this) == "auto")
    }

    private fun setKeepAwake(on: Boolean) {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            if (on && keepAwakeView == null) {
                val v = View(this)
                val lp = WindowManager.LayoutParams(
                    1, 1,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                )
                wm.addView(v, lp)
                keepAwakeView = v
                LogStore.append(this, "إبقاء الشاشة شغالة: مفعّل")
            } else if (!on && keepAwakeView != null) {
                wm.removeView(keepAwakeView)
                keepAwakeView = null
                LogStore.append(this, "إبقاء الشاشة شغالة: متوقف")
            }
        } catch (e: Exception) {
            LogStore.append(this, "تعذر إبقاء الشاشة شغالة: ${e.message}")
        }
    }

    // v0.40: the screen tree can change under us mid-walk (nodes vanish -> NPE). Never let
    // that kill the service: log it and carry on with the next event.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            handleEvent(event)
        } catch (e: Exception) {
            LogStore.append(this, "خطأ تم تجاوزه: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(80)}")
        }
    }

    private fun handleEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != YOKI_PACKAGE) return
        if (!SettingsStore.isMonitorEnabled(this)) { setKeepAwake(false); return }
        if (keepAwakeView == null) updateKeepAwake()
        // Debounce: Yoki fires many content-changed events per keystroke.
        pendingCheck?.let { handler.removeCallbacks(it) }
        val check = Runnable { processChatIfNeeded() }
        pendingCheck = check
        handler.postDelayed(check, DEBOUNCE_MS)
    }

    /** Diagnostic line, deduped so the log is not flooded on the chat list. */
    private fun logDiag(msg: String) {
        if (msg == lastDiag) return
        lastDiag = msg
        LogStore.append(this, msg)
    }

    private fun processChatIfNeeded() {
        try {
            processChatIfNeededInner()
        } catch (e: Exception) {
            LogStore.append(this, "خطأ تم تجاوزه: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(80)}")
        }
    }

    private fun processChatIfNeededInner() {
        if (isProcessing) return
        val root = rootInActiveWindow ?: return
        if (handleRewardPopup(root)) return
        val width = resources.displayMetrics.widthPixels
        val density = resources.displayMetrics.density
        val bubbles = mutableListOf<Bubble>()
        val clickables = mutableListOf<SendCandidate>()
        var input: AccessibilityNodeInfo? = null
        var sendButton: AccessibilityNodeInfo? = null
        var sendHow = ""
        collect(root, bubbles, clickables) { node, viewId, text ->
            if (input == null && node.isEditable) input = node
            if (sendButton == null && isSendControl(node, viewId, text)) {
                sendButton = node
                sendHow = "بالاسم"
            }
        }
        // v0.32: Yoki's "أرباح اليوم" popup can pop up over a chat too — press "الرد الآن".
        if (input != null && !isProcessing) {
            val nowP = System.currentTimeMillis()
            if (nowP - lastPopupAt > 25_000L && nowP - lastReplyAt > 6_000L) {
                val btn = findClickableByText(root, "الرد الآن")
                if (btn != null && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    lastPopupAt = nowP
                    currentRowSig = null
                    openedFromList = true
                    LogStore.append(this, "نافذة «الرد الآن» (فوق محادثة) — فتح المحادثة")
                    scheduleWatchdog(0)
                    return
                }
            }
        }
        // Not a chat screen (list, profile, …) — log why, once per state.
        if (input == null) {
            if (!scanChatList(root)) {
                logDiag("تشخيص: لا توجد خانة كتابة — ليست شاشة محادثة")
            }
            return
        }
        // Position fallback: the Yoki send arrow has no "send" id/label.
        // v0.8: في وضع المسودة مش محتاجين زر الإرسال أصلاً — البوت بيكتب
        // بس وانت اللي بتدوس إرسال — فمنرجعش بدري لو الزرار مش موجود.
        val draftOn = SettingsStore.draftMode(this)
        if (sendButton == null) {
            val byPos = findSendByPosition(clickables, input, density)
            if (byPos != null) {
                sendButton = byPos.node
                sendHow = "بالمكان"
            }
        }
        if (sendButton == null && !draftOn) {
            logDiag("تشخيص: خانة كتابة موجودة لكن لا يوجد زر إرسال (لا بالاسم ولا بالمكان) — فقاعات: ${bubbles.size}")
            return
        }
        if (sendButton == null) sendHow = "مسودة"

        val inputTop = Rect().also { input?.getBoundsInScreen(it) }.top
        // v0.7: quick-reply chips sit just above the input bar (~80dp) and
        // were mistaken for the last message ("تعرف"). Ignore them by exact
        // text and by proximity to the input top.
        val chipCutoff = inputTop - (80 * density).toInt()
        // v0.16: the old rule dropped EVERYTHING within 80dp above the input, which also
        // dropped the real last message when the chat is short (the bot then saw an older
        // message of its own and never replied). Chips are a ROW of 2+ texts at the same
        // height near the input; a single text there is a real message.
        val rowTol = (12 * density).toInt()
        val zone = bubbles.filter { it.bottom >= chipCutoff && it.top < inputTop }
        val chipRowTexts = zone
            .filter { a -> zone.count { b -> kotlin.math.abs(b.bottom - a.bottom) < rowTol } >= 2 }
            .map { it.text }
            .toSet()
        val chipCount = bubbles.count { isQuickReplyChip(it.text) || it.text in chipRowTexts }
        if (chipCount > 0) {
            logDiag("تشخيص: تم تجاهل اقتراحات رد سريعة: $chipCount")
        }
        val chatBubbles = bubbles
            .filter {
                // v0.22: a bubble partly hidden under the input bar (its bottom is below the
                // bar's top) is still a message — judge by its TOP, not its bottom.
                it.top < inputTop - (8 * density).toInt() && it.text.length in 1..500 &&
                    !isPromoText(it.text) && !isSystemBubble(it.text) &&
                    !isQuickReplyChip(it.text) && it.text !in chipRowTexts &&
                    !isCounterTag(it.text)
            }
            // v0.24: follow only real chat bubbles — mine (own side) or the other
            // person's white bubbles (other side). Wide / full-width texts (Yoki's
            // system banners) are neither, so they are ignored by shape, not just by text.
            .filter { isOwnBubble(it, width) || isIncomingBubble(it, width) }
            .sortedBy { it.bottom }
        if (chatBubbles.isEmpty()) {
            markRowIdle()
            logDiag("تشخيص: خانة=نعم إرسال=نعم ($sendHow) لكن لا توجد فقاعات رسائل")
            return
        }

        // v0.43 (experimental): a sticker/emoji is an image, not text — the tree gives no
        // words for it. Look for a mid-sized, text-less image on the other person's side that
        // sits BELOW the newest text message (so it is the newest thing in the chat).
        val lastText = chatBubbles.last()
        val stickerBubble = findNewSticker(root, lastText, inputTop, width, density)
        val last = stickerBubble ?: lastText
        if (isSystemBubble(last.text)) {
            markRowIdle()
            logDiag("تشخيص: تم تجاهل رسالة نظام: ${last.text.take(60)}")
            return
        }
        val lastSentText = SettingsStore.prefs(this).getString(SettingsStore.KEY_LAST_SENT, null)
        // v0.17: "same text as my last reply" only counts when the bubble sits in the
        // middle (side unclear). Otherwise, when the other person says exactly what I
        // last sent (e.g. both "هلا"), his message was being ignored.
        val lastRatio = last.centerX / width.toFloat()
        val lastSent = if (lastRatio in 0.35f..0.65f) lastSentText else null
        val own = isOwnBubble(last, width)
        // v0.8: لو المستخدم بعت رسالة بنفسه (منها مسودة كان جهزها وداس
        // إرسال)، المسودة مبقتش مستنية — امسحها عشان المسودة الجاية
        // تتسجل جديدة مش "تحديث مسودة".
        if (own && pendingDraftHash != null) pendingDraftHash = null
        // v0.20: a keyword match is answered at once — it skips the between-replies cooldown.
        val isKeyword = SettingsStore.matchKeywordReply(this, last.text) != null
        val canReply = last.text != lastSent && !own &&
            ReplyStore.shouldReply(this, last.text.hashCode(), ignoreCooldown = isKeyword)
        logDiag(
            "تشخيص: خانة=نعم إرسال=نعم ($sendHow) فقاعات=${chatBubbles.size} " +
                "آخر رسالة: ${last.text.take(60)} صاحبها؟=${if (own) "نعم" else "لا"} " +
                "يرد؟=${if (canReply) "نعم" else "لا"}"
        )
        if (last.text == lastSent || own) {
            // v0.16: the last message is ours — nothing to answer; do not reopen this row for a while.
            markRowIdle()
            return
        }

        val nowMs = System.currentTimeMillis()
        if (last.text == lastReplyText && nowMs - lastReplyAt < 60_000L &&
            chatBubbles.size <= lastReplyBubbleCount
        ) {
            markRowIdle()
            logDiag("تشخيص: تم الرد على هذه الرسالة قبل شوية ولسه مفيش رسالة جديدة")
            return
        }
        val hash = last.text.hashCode()
        if (!ReplyStore.shouldReply(this, hash, ignoreCooldown = isKeyword)) return

        isProcessing = true
        val history = chatBubbles.dropLast(1).takeLast(12).map { (if (isOwnBubble(it, width)) "أنا: " else "هو: ") + it.text }
        val incoming = last.text
        scope.launch {
            try {
                // v0.7: the user's own words come first — cycle through his
                // custom replies in order instead of calling the AI.
                // v0.11: الكلمات المفتاحية أولاً.
                var reply: String? = SettingsStore.matchKeywordReply(this@YokiAccessibilityService, incoming)
                if (reply != null) {
                    LogStore.append(this@YokiAccessibilityService, "رد بكلمة مفتاحية")
                } else {
                    LogStore.append(
                        this@YokiAccessibilityService,
                        "كلمات مفتاحية: لا يوجد تطابق مع «${incoming.take(40)}» — القواعد المحفوظة: " +
                            "${SettingsStore.keywordRulesCount(this@YokiAccessibilityService)}"
                    )
                }
                // v0.37: a voice message shows up as just its length ("٠٠:٠٨") — the bot cannot
                // listen to it, so it gets a fixed reply instead of an AI guess about "00:08".
                if (reply == null && SettingsStore.isVoiceMessage(incoming)) {
                    reply = SettingsStore.voiceReply(this@YokiAccessibilityService)
                    LogStore.append(this@YokiAccessibilityService, "رسالة صوتية — رد ثابت")
                }
                if (reply == null && incoming == STICKER_TEXT) {
                    reply = SettingsStore.stickerReply(this@YokiAccessibilityService)
                    LogStore.append(this@YokiAccessibilityService, "ستيكر — رد ثابت")
                }
                val customList = SettingsStore.customReplies(this@YokiAccessibilityService)
                if (reply == null && customList.isNotEmpty()) {
                    val idx = SettingsStore.customReplyIndex(this@YokiAccessibilityService) % customList.size
                    reply = SettingsStore.nextCustomReply(this@YokiAccessibilityService)
                    if (reply != null) {
                        LogStore.append(this@YokiAccessibilityService, "استخدام رد مخصص رقم ${idx + 1} من ${customList.size}")
                    }
                }
                if (reply == null) {
                    reply = AiClient.generateReply(this@YokiAccessibilityService, history, incoming)
                    if (reply == null && SettingsStore.useFallback(this@YokiAccessibilityService)) {
                        reply = SettingsStore.fallbackReply(this@YokiAccessibilityService)
                        LogStore.append(this@YokiAccessibilityService, "الذكاء فشل — استخدام الرد الاحتياطي")
                    }
                }
                if (reply.isNullOrBlank()) {
                    LogStore.append(this@YokiAccessibilityService, "لم يتم توليد رد — تم التخطي (تأكد من مفتاح API)")
                    return@launch
                }
                val textToSend = reply
                val mode = SettingsStore.replyMode(this@YokiAccessibilityService)
                // v0.8: وضع المسودة — اكتب الرد زي ما هو (من غير سطر البوت،
                // لأن انت اللي هتبعت بنفسك بعد ما تراجعه) وميدوسش إرسال.
                // "off" يفضل مراقبة بس حتى في وضع المسودة.
                if (SettingsStore.draftMode(this@YokiAccessibilityService) && mode != "off") {
                    handler.post { prepareDraft(textToSend, hash) }
                    return@launch
                }
                val finalReply = SettingsStore.ensureTransparent(textToSend)
                when (mode) {
                    "auto" -> {
                        lastReplyText = incoming
                        lastReplyAt = System.currentTimeMillis()
                        lastReplyBubbleCount = chatBubbles.size
                        handler.post { performSend(finalReply, hash) }
                    }
                    "off" -> {
                        LogStore.append(this@YokiAccessibilityService, "وضع الإيقاف: رصد فقط — آخر وارد: ${incoming.take(60)}")
                    }
                    else -> { // manual
                        SettingsStore.prefs(this@YokiAccessibilityService).edit()
                            .putString(SettingsStore.KEY_PENDING_REPLY, finalReply)
                            .putInt(SettingsStore.KEY_PENDING_HASH, hash)
                            .apply()
                        NotificationHelper.showApprovalNotification(
                            this@YokiAccessibilityService, incoming, finalReply
                        )
                        LogStore.append(this@YokiAccessibilityService, "رد مقترح جاهز للموافقة: ${finalReply.take(60)}")
                    }
                }
            } finally {
                isProcessing = false
            }
        }
    }

    /** Called from ReplyActionReceiver after the user taps "Send". */
    fun sendApprovedReply(reply: String, hash: Int) {
        handler.post { performSend(reply, hash) }
    }

    /**
     * v0.8 — وضع المسودة: يكتب الرد في خانة الكتابة بس، وميدوسش إرسال.
     * - لو نفس الرسالة اتجهزت مسودتها قبل كده، ميتكتبش تاني (عشان ميمسحش
     *   تعديل المستخدم على المسودة وهي مستنية).
     * - لو رسالة جديدة وصلت والمسودة القديمة لسه مستنية، بتتبدل بالرد
     *   الجديد وبيتكتب "تم تحديث المسودة".
     * - بيتسجل في ReplyStore زي الرد المرسل: الفاصل وحد الساعة بيتطبقوا
     *   على تجهيز المسودة برضه.
     */
    private fun prepareDraft(text: String, hash: Int) {
        if (pendingDraftHash == hash) return // المسودة دي جاهزة أصلاً — متعيدش الكتابة
        val isUpdate = pendingDraftHash != null
        if (!typeIntoInput(text)) {
            LogStore.append(this, "تعذر كتابة المسودة في خانة Yoki")
            return
        }
        pendingDraftHash = hash
        ReplyStore.markReplied(this, hash)
        if (isUpdate) {
            LogStore.append(this, "تم تحديث المسودة: ${text.take(60)}")
        } else {
            LogStore.append(this, "تم تجهيز مسودة، في انتظار إرسالك: ${text.take(60)}")
        }
    }

    /** يكتب نص في خانة Yoki (ACTION_SET_TEXT، وبديل اللصق من الحافظة لو منفعش). */
    private fun typeIntoInput(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val input = findEditable(root) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        var written = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!written) {
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("draft", text))
            written = input.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
        return written
    }

    private fun performSend(rawText: String, hash: Int) {
        val text = SettingsStore.ensureTransparent(rawText)
        val root = rootInActiveWindow ?: return
        val input = findEditable(root) ?: run {
            LogStore.append(this, "تعذر الإرسال: لم أجد خانة الكتابة")
            return
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        var written = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (!written) {
            // Fallback: focus + paste from clipboard.
            input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("reply", text))
            written = input.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }
        if (!written) {
            LogStore.append(this, "تعذر كتابة الرد في خانة Yoki")
            return
        }
        // Re-fetch the tree: the send button may have changed after typing
        // (in Yoki the arrow only appears once there is text to send).
        val freshRoot = rootInActiveWindow ?: return
        var send = findSendControl(freshRoot)
        var sendHow = "بالاسم"
        if (send == null) {
            val typedInput = findEditable(freshRoot)
            if (typedInput != null) {
                val cands = mutableListOf<SendCandidate>()
                collect(freshRoot, mutableListOf(), cands) { _, _, _ -> }
                val byPos = findSendByPosition(cands, typedInput, resources.displayMetrics.density)
                if (byPos != null) {
                    send = byPos.node
                    sendHow = "بالمكان"
                }
            }
            if (send == null) {
                LogStore.append(this, "تشخيص: بعد الكتابة لم أجد زر إرسال (لا بالاسم ولا بالمكان)")
            }
        }
        val clicked = send?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        if (clicked) {
            ReplyStore.markReplied(this, hash)
            SettingsStore.prefs(this).edit()
                .putString(SettingsStore.KEY_LAST_SENT, text)
                .remove(SettingsStore.KEY_PENDING_REPLY)
                .remove(SettingsStore.KEY_PENDING_HASH)
                .apply()
            NotificationHelper.cancelApproval(this)
            LogStore.append(this, "تم إرسال الرد ($sendHow): ${text.take(60)}")
            // v0.6: the emoji panel sometimes opens on the tap that sends.
            // Give it a moment to appear, then close it with BACK once.
            handler.postDelayed({
                val r = rootInActiveWindow
                if (r != null && isEmojiPanelOpen(r)) {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    LogStore.append(this, "تم إغلاق لوحة الإيموجي")
                }
            }, 400)
            // v0.9: لو المحادثة اتفتحت تلقائياً، ارجع لقائمة الرسائل.
            if (openedFromList) {
                handler.postDelayed({ returnToList(0) }, 900)
            }
        } else {
            LogStore.append(this, "تمت الكتابة لكن تعذر الضغط على زر الإرسال — أرسله يدوياً")
        }
    }


    // ---- v0.9: auto-open chats from the messages list ----

    /** Called by YokiNotificationListener after it opened a chat from a notification. */
    fun noteOpenedFromNotification() {
        handler.post {
            if (SettingsStore.draftMode(this)) return@post
            openedFromList = true
            scheduleWatchdog(0)
        }
    }

    /**
     * On the "الرسائل" list: open a row that has an unread-count badge OR whose
     * preview is Yoki's "[اربح الألماس]" bait (a chat still waiting for a reply),
     * and tap the "الرد الآن" popup when it shows. Returns true if something was clicked.
     */
    private fun scanChatList(root: AccessibilityNodeInfo): Boolean {
        if (!SettingsStore.autoOpenNotifications(this)) return false
        if (SettingsStore.draftMode(this)) return false
        if (SettingsStore.replyMode(this) != "auto") return false
        if (root.packageName?.toString() != YOKI_PACKAGE) return false
        if (isProcessing || openedFromList) return false
        val now = System.currentTimeMillis()
        if (now - lastListClickAt < 3000L) {
            scheduleRecheck(1000L)
            return false
        }
        // Respect cooldown / hourly cap before opening anything (hash 1 is a dummy).
        // The list is static, so no event would wake us when the cooldown ends —
        // re-check by timer instead of waiting for a UI event.
        if (!ReplyStore.shouldReply(this, 1)) {
            scheduleRecheck(1500L)
            return false
        }
        // v0.13: Yoki's "أرباح اليوم" popup with a "الرد الآن" button.
        if (now - lastPopupAt > 25_000L) {
            val popupBtn = findClickableByText(root, "الرد الآن")
            if (popupBtn != null && popupBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                lastPopupAt = now
                currentRowSig = null
                openedFromList = true
                lastListClickAt = now
                LogStore.append(this, "نافذة «الرد الآن» — فتح المحادثة")
                scheduleWatchdog(0)
                return true
            }
        }
        // Only on the messages list screen (its title).
        if (!findText(root, setOf("الرسائل"))) return false

        val dm = resources.displayMetrics
        val minRowW = (dm.widthPixels * 0.7f).toInt()
        val maxRowH = (dm.heightPixels * 0.25f).toInt()
        val anchors = mutableListOf<AccessibilityNodeInfo>()
        findBadges(root, anchors, dm.widthPixels, dm.heightPixels, dm.density)
        findDiamondTexts(root, anchors, dm.heightPixels)
        for (b in anchors) {
            var p: AccessibilityNodeInfo? = b.parent
            var depth = 0
            while (p != null && depth < 8) {
                if (p.isClickable) {
                    val r = Rect()
                    p.getBoundsInScreen(r)
                    if (r.width() >= minRowW && r.height() in 1..maxRowH) {
                        val texts = mutableListOf<String>()
                        gatherTexts(p, texts)
                        val sig = texts.joinToString("|")
                        currentRowSig = sig
                        val isDiamond = texts.any { isDiamondPreview(it) }
                        currentRowDiamond = isDiamond
                        val lastHandled = handledListSigs[sig]
                        // Badge rows: once per (text, count). Diamond rows: retry every 15 s
                        // until the bait disappears, so none is left unanswered.
                        if (lastHandled != null && !(isDiamond && now - lastHandled > 15_000L)) break
                        // Rows whose last message is a Yoki system message are not worth opening.
                        if (texts.any { isSystemBubble(it) || isPromoText(it) }) {
                            handledListSigs[sig] = now
                            break
                        }
                        if (handledListSigs.size > 200) handledListSigs.clear()
                        handledListSigs[sig] = now
                        val name = texts.firstOrNull { !isBadgeText(it) }.orEmpty().take(30)
                        if (p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            openedFromList = true
                            lastListClickAt = now
                            LogStore.append(this, "رسالة جديدة في القائمة — فتح المحادثة: $name")
                            scheduleWatchdog(0)
                            return true
                        }
                        break
                    }
                }
                p = p.parent
                depth++
            }
        }
        return sweepList(root)
    }

    // v0.29: rows below the visible part of the list (badge / "[اربح الألماس]") are reached by
    // scrolling down a few screens, then back to the top, resting between sweeps.
    private var listScrollSteps = 0
    private var lastListScrollAt = 0L
    private var lastSweepEndAt = 0L

    private fun findScrollable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        val cls = node.className?.toString().orEmpty()
        if (node.isScrollable && (cls.contains("RecyclerView") || cls.contains("ListView") || cls.contains("ScrollView"))) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.height() > resources.displayMetrics.heightPixels * 0.4f) return node
        }
        for (i in 0 until node.childCount) findScrollable(node.getChild(i))?.let { return it }
        return null
    }

    private fun sweepList(root: AccessibilityNodeInfo): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastSweepEndAt < 8000L) {
            scheduleRecheck(3000L)
            return false
        }
        if (now - lastListScrollAt < 1400L) {
            scheduleRecheck(1400L)
            return false
        }
        val sc = findScrollable(root)
        if (sc == null) {
            lastSweepEndAt = now
            scheduleRecheck(8000L)
            return false
        }
        if (listScrollSteps < 8 && sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            listScrollSteps++
            lastListScrollAt = now
            scheduleRecheck(1500L)
            return false
        }
        // Reached the end (or step limit): go back to the top.
        val back = listScrollSteps + 1
        for (i in 0 until back) {
            handler.postDelayed({ sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) }, 350L * i)
        }
        listScrollSteps = 0
        lastSweepEndAt = now + 350L * back
        lastListScrollAt = now + 350L * back
        scheduleRecheck(350L * back + 2000L)
        return false
    }

    /** Opened a row but there was nothing to answer: block reopening it for ~2 minutes. */
    // v0.31: a "[اربح الألماس]" row is still waiting for an answer, so it is retried soon
    // (≈20 s) instead of being parked for 2 minutes like an ordinary row.
    private var currentRowDiamond = false

    private fun markRowIdle() {
        if (!openedFromList) return
        val sig = currentRowSig ?: return
        val park = if (currentRowDiamond) 5_000L else 120_000L
        handledListSigs[sig] = System.currentTimeMillis() + park
    }

    /** Small counters like "x36" / "x24" next to bubbles are not messages. */
    private fun isCounterTag(text: String): Boolean {
        val t = text.trim()
        if (t.length < 2 || t.length > 6) return false
        val c = t[0]
        if (c != 'x' && c != 'X' && c != '\u00D7') return false
        return t.substring(1).trim().all { it in '0'..'9' }
    }

    private fun isDiamondPreview(t: String): Boolean = t.contains("اربح") && t.contains("ماس")

    private fun findDiamondTexts(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, height: Int) {
        if (node == null) return
        val text = node.text?.toString()?.trim().orEmpty()
        val cls = node.className?.toString() ?: ""
        if (cls.contains("TextView") && isDiamondPreview(text)) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.height() > 0 && r.centerY() < height * 0.885f) out.add(node)
        }
        for (i in 0 until node.childCount) findDiamondTexts(node.getChild(i), out, height)
    }

    private fun findClickableByText(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val t = root.text?.toString()?.trim().orEmpty()
        val d = root.contentDescription?.toString()?.trim().orEmpty()
        if (t == label || d == label || t.contains(label) || d.contains(label)) {
            var p: AccessibilityNodeInfo? = root
            var depth = 0
            while (p != null && depth < 8) {
                if (p.isClickable) return p
                p = p.parent
                depth++
            }
        }
        for (i in 0 until root.childCount) {
            val c = root.getChild(i) ?: continue
            findClickableByText(c, label)?.let { return it }
        }
        return null
    }

    private fun scheduleRecheck(ms: Long) {
        pendingCheck?.let { handler.removeCallbacks(it) }
        val check = Runnable { processChatIfNeeded() }
        pendingCheck = check
        handler.postDelayed(check, ms)
    }

    private fun isBadgeText(t: String): Boolean {
        val s = t.trim()
        if (s.isEmpty() || s.length > 4) return false
        val digits = s.removeSuffix("+")
        return digits.isNotEmpty() && digits.all { it in '0'..'9' || it in '\u0660'..'\u0669' }
    }

    /** Small numeric TextViews on the avatar side (right, RTL), above the bottom bar. */
    private fun findBadges(
        node: AccessibilityNodeInfo?,
        out: MutableList<AccessibilityNodeInfo>,
        width: Int,
        height: Int,
        density: Float
    ) {
        if (node == null) return
        val text = node.text?.toString()?.trim().orEmpty()
        val cls = node.className?.toString() ?: ""
        if (cls.contains("TextView") && isBadgeText(text)) {
            val r = Rect()
            node.getBoundsInScreen(r)
            val maxSize = (48 * density).toInt()
            if (r.width() in 1..maxSize && r.height() in 1..maxSize &&
                r.centerX() > width * 0.6f && r.centerY() < height * 0.885f
            ) {
                out.add(node)
            }
        }
        for (i in 0 until node.childCount) findBadges(node.getChild(i), out, width, height, density)
    }

    private fun gatherTexts(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null) return
        val t = node.text?.toString()?.trim().orEmpty()
        if (t.isNotEmpty()) out.add(t)
        for (i in 0 until node.childCount) gatherTexts(node.getChild(i), out)
    }

    /** Safety timer: if the auto-opened chat was not answered, go back to the list. */
    private fun scheduleWatchdog(retry: Int) {
        watchdog?.let { handler.removeCallbacks(it) }
        val w = Runnable {
            if (openedFromList) {
                if (isProcessing && retry < 6) {
                    scheduleWatchdog(retry + 1)
                } else {
                    returnToList(0)
                }
            }
        }
        watchdog = w
        handler.postDelayed(w, 10000L)
    }

    /** Press BACK (keyboard / panel first, then the chat) until we are out of the chat. */
    private fun returnToList(attempt: Int) {
        watchdog?.let { handler.removeCallbacks(it) }
        val root = rootInActiveWindow
        val inChat = root != null &&
            root.packageName?.toString() == YOKI_PACKAGE &&
            findEditable(root) != null
        if (!inChat || attempt >= 4) {
            openedFromList = false
            // v0.11: look at the list again soon (another badge may be waiting).
            scheduleRecheck(800L)
            return
        }
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({ returnToList(attempt + 1) }, 600)
    }

    // ---- node-tree helpers ----

    private fun collect(
        node: AccessibilityNodeInfo?,
        bubbles: MutableList<Bubble>,
        clickables: MutableList<SendCandidate>,
        onNode: (AccessibilityNodeInfo, String, String) -> Unit
    ) {
        if (node == null) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val viewId = node.viewIdResourceName ?: ""
        val className = node.className?.toString() ?: ""
        onNode(node, viewId, text.ifBlank { desc })
        if (node.isClickable) {
            val rect = Rect().also { node.getBoundsInScreen(it) }
            if (rect.width() > 0 && rect.height() > 0) {
                clickables.add(
                    SendCandidate(
                        node, text.ifBlank { desc }, viewId, desc,
                        rect.centerX(), rect.centerY(),
                        rect.width(), rect.height(), className
                    )
                )
            }
        }
        if (text.isNotBlank() && className.contains("TextView")) {
            val rect = Rect().also { node.getBoundsInScreen(it) }
            if (rect.width() > 0 && rect.height() > 0) {
                bubbles.add(Bubble(text, viewId, rect.centerX().toFloat(), rect.bottom, rect.top, rect.left, rect.right, className))
            }
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), bubbles, clickables, onNode)
    }

    private fun isSendControl(node: AccessibilityNodeInfo, viewId: String, text: String): Boolean {
        if (!node.isClickable) return false
        val desc = node.contentDescription?.toString() ?: ""
        if (isExcludedIcon(viewId, text, desc)) return false
        val id = viewId.lowercase()
        val label = (text + " " + desc).lowercase()
        return id.contains("send") || id.contains("btn_send") ||
            label.contains("send") || label.contains("إرسال") || label.contains("ارسال")
    }

    /**
     * Position fallback (v0.6, tightened): the Yoki send arrow is an image
     * icon IMMEDIATELY adjacent to the editable input — closest horizontal
     * gap within ~48dp of the input's edge, roughly square, 24-64dp.
     * The emoji / phone / gift / image / mic icons also live in the input
     * bar, but they are further from the input edge and are explicitly
     * excluded by isExcludedIcon(). Prefer an icon to the LEFT of the
     * input (the RTL send arrow). No arbitrary text-less clickable is
     * accepted any more — that is what opened the emoji panel in v0.5.
     */
    private fun findSendByPosition(
        candidates: List<SendCandidate>,
        input: AccessibilityNodeInfo,
        density: Float
    ): SendCandidate? {
        val inRect = Rect().also { input.getBoundsInScreen(it) }
        val band = (24 * density).toInt()
        val maxGap = (48 * density).toInt()
        val minSize = (24 * density).toInt()
        val maxSize = (64 * density).toInt()
        val top = inRect.top - band
        val bottom = inRect.bottom + band
        fun gapPx(c: SendCandidate): Int =
            if (c.centerX < inRect.left) inRect.left - c.centerX
            else if (c.centerX > inRect.right) c.centerX - inRect.right
            else 0
        val usable = candidates.filter { c ->
            c.node != input &&
                c.centerY in top..bottom &&
                gapPx(c) <= maxGap &&
                c.width in minSize..maxSize &&
                c.height in minSize..maxSize &&
                !isExcludedIcon(c.viewId, c.text, c.desc)
        }
        if (usable.isEmpty()) return null
        fun isImage(c: SendCandidate) =
            c.className.contains("ImageView") || c.className.contains("ImageButton")
        val leftImages = usable.filter { it.centerX < inRect.left && isImage(it) }
        if (leftImages.isNotEmpty()) {
            return leftImages.minByOrNull { gapPx(it) }
        }
        val images = usable.filter { isImage(it) }
        if (images.isNotEmpty()) {
            return images.minByOrNull { gapPx(it) }
        }
        return usable.minByOrNull { gapPx(it) }
    }

    /** True when an emoji panel (its category labels) is visible. */
    private fun isEmojiPanelOpen(root: AccessibilityNodeInfo): Boolean {
        val labels = setOf("المضحك", "السعادة", "بكاء", "ابتسامة", "القهقهة")
        return findText(root, labels)
    }

    private fun findText(node: AccessibilityNodeInfo?, labels: Set<String>): Boolean {
        if (node == null) return false
        val text = node.text?.toString()?.trim().orEmpty()
        if (text in labels) return true
        for (i in 0 until node.childCount) {
            if (findText(node.getChild(i), labels)) return true
        }
        return false
    }

    /** Yoki quick-reply suggestion chips ("هاي", "تعرف", ...) are buttons,
     * not messages — never treat them as the last incoming message. */
    private fun isQuickReplyChip(text: String): Boolean {
        val t = text.trim()
        return t == "هاي" || t == "تعرف" || t == "ممكن نتعرف..." || t == "ممكن نتعرف"
    }

    /** System join/promo bubbles are not messages — never reply to them. */
    private fun isSystemBubble(text: String): Boolean = isYokiSystemText(this, text)

    /** System / promo TextViews on the chat screen are not messages. */
    private fun isPromoText(text: String): Boolean {
        val t = text.trim()
        return t.contains("فتح الدردشة الصوتية") ||
            t.contains("اتصل الآن") ||
            t.startsWith("New")
    }

    // v0.46: Yoki's centred reward popup ("مبروك! … اذهب لاستلامها") — press the button, then
    // press the claim button on the page it opens (if any), and come back to the list.
    private var lastRewardAt = 0L
    private var rewardFollowUntil = 0L
    private var rewardBacks = 0

    private val lastAutoClickAt = mutableMapOf<String, Long>()

    // v0.48: buttons named by the user in the settings are pressed whenever they show up
    // (at most once every 6 s per button, so a button that stays on screen is not hammered).
    private fun handleUserButtons(root: AccessibilityNodeInfo): Boolean {
        val labels = SettingsStore.autoClickLabels(this)
        if (labels.isEmpty()) return false
        val now = System.currentTimeMillis()
        for (label in labels) {
            if (now - (lastAutoClickAt[label] ?: 0L) < 6_000L) continue
            val btn = findClickableByText(root, label) ?: continue
            if (btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                lastAutoClickAt[label] = now
                LogStore.append(this, "ضغط زرار: «$label»")
                scheduleRecheck(1500L)
                return true
            }
        }
        return false
    }

    private var lastSheetAt = 0L
    private var sheetTries = 0

    private fun containsText(node: AccessibilityNodeInfo?, sub: String): Boolean {
        if (node == null) return false
        if (node.text?.toString()?.contains(sub) == true) return true
        for (i in 0 until node.childCount) if (containsText(node.getChild(i), sub)) return true
        return false
    }

    private fun findCloseX(node: AccessibilityNodeInfo?, w: Int, h: Int): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isClickable && node.text.isNullOrEmpty()) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.left < 0.2f * w && r.centerY() > 0.15f * h && r.centerY() < 0.4f * h &&
                r.width() > 0.04f * w && r.width() < 0.14f * w && r.height() < 0.14f * w
            ) return node
        }
        for (i in 0 until node.childCount) findCloseX(node.getChild(i), w, h)?.let { return it }
        return null
    }

    // v0.47: the "مكافأة الترحيب اليومية" sheet — press «استلام المكافأة» if it is enabled,
    // then close it with the ✕ (or Back if the ✕ cannot be found).
    private fun handleRewardSheet(root: AccessibilityNodeInfo): Boolean {
        if (!containsText(root, "مكافأة الترحيب")) {
            sheetTries = 0
            return false
        }
        val now = System.currentTimeMillis()
        if (now - lastSheetAt < 2_000L) return true
        lastSheetAt = now
        sheetTries++
        val claim = findClickableByText(root, "استلام المكافأة")
        if (claim != null && claim.isEnabled && sheetTries == 1 &&
            claim.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        ) {
            LogStore.append(this, "صفحة المكافأة — ضغط «استلام المكافأة»")
            scheduleRecheck(2200L)
            return true
        }
        val dm = resources.displayMetrics
        var closed = false
        for (label in listOf("إغلاق", "اغلاق", "Close", "close")) {
            val b = findClickableByText(root, label)
            if (b != null && b.performAction(AccessibilityNodeInfo.ACTION_CLICK)) { closed = true; break }
        }
        if (!closed) {
            val x = findCloseX(root, dm.widthPixels, dm.heightPixels)
            if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) closed = true
        }
        if (closed) {
            LogStore.append(this, "صفحة المكافأة — ضغط ✕ للإغلاق")
        } else if (sheetTries >= 3) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            LogStore.append(this, "صفحة المكافأة — لم أجد ✕، رجوع")
        }
        scheduleRecheck(2200L)
        return true
    }

    private fun handleRewardPopup(root: AccessibilityNodeInfo): Boolean {
        val now = System.currentTimeMillis()
        if (handleRewardSheet(root)) return true
        if (handleUserButtons(root)) return true
        if (now - lastRewardAt > 8_000L) {
            for (label in listOf("اذهب لاستلامها", "استلمها الآن")) {
                val btn = findClickableByText(root, label)
                if (btn != null && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    lastRewardAt = now
                    rewardFollowUntil = now + 20_000L
                    rewardBacks = 0
                    currentRowSig = null
                    LogStore.append(this, "نافذة مكافأة — ضغط «$label»")
                    scheduleRecheck(2500L)
                    return true
                }
            }
        }
        if (now < rewardFollowUntil && now - lastRewardAt > 2_000L) {
            for (label in listOf("استلام", "استلم", "استلمها", "Claim")) {
                val btn = findClickableByText(root, label)
                if (btn != null && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    LogStore.append(this, "صفحة المكافأة — ضغط «$label»")
                    rewardFollowUntil = now + 8_000L
                    scheduleRecheck(2500L)
                    return true
                }
            }
            // Not on the messages list or a chat any more → go back (at most twice).
            val onList = findText(root, setOf("الرسائل"))
            val onChat = findEditable(root) != null
            if (!onList && !onChat && rewardBacks < 2 && now - lastRewardAt > 5_000L) {
                rewardBacks++
                performGlobalAction(GLOBAL_ACTION_BACK)
                LogStore.append(this, "صفحة المكافأة — رجوع ($rewardBacks)")
                scheduleRecheck(2000L)
                return true
            }
        }
        return false
    }

    private val STICKER_TEXT = "[ستيكر]"

    private fun collectImages(node: AccessibilityNodeInfo?, out: MutableList<Rect>) {
        if (node == null) return
        val cls = node.className?.toString().orEmpty()
        if (cls.contains("ImageView") && node.text.isNullOrEmpty() && node.isVisibleToUser) {
            val r = Rect()
            node.getBoundsInScreen(r)
            out.add(r)
        }
        for (i in 0 until node.childCount) collectImages(node.getChild(i), out)
    }

    private fun findNewSticker(root: AccessibilityNodeInfo, lastText: Bubble, inputTop: Int, width: Int, density: Float): Bubble? {
        val height = resources.displayMetrics.heightPixels
        val tol = (6 * density).toInt()
        val imgs = mutableListOf<Rect>()
        collectImages(root, imgs)
        val newer = imgs.filter { r ->
            r.top >= lastText.bottom - tol && r.bottom <= inputTop + tol &&
                r.centerY() > height * 0.2f && r.width() > 0 && r.height() > 0
        }
        if (newer.isNotEmpty()) {
            logDiag("تشخيص: صور بعد آخر رسالة: " + newer.joinToString(" ") {
                "${(it.width() / density).toInt()}x${(it.height() / density).toInt()}dp@${(it.centerX() * 100f / width).toInt()}%"
            })
        }
        val mineLeft = SettingsStore.myMessagesOnLeft(this)
        val cand = newer.firstOrNull { r ->
            val w = r.width().toFloat() / width
            val h = r.height().toFloat() / width
            val ratio = r.centerX().toFloat() / width
            val sideOk = if (mineLeft) ratio > 0.45f else ratio < 0.55f
            w in 0.13f..0.45f && h in 0.13f..0.45f && sideOk
        } ?: return null
        return Bubble(STICKER_TEXT, "", cand.centerX().toFloat(), cand.bottom, cand.top, cand.left, cand.right, "Sticker")
    }

    private fun findEditable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        if (root.isEditable) return root
        for (i in 0 until root.childCount) {
            findEditable(root.getChild(i))?.let { return it }
        }
        return null
    }

    private fun findSendControl(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        val text = root.text?.toString().orEmpty()
        if (isSendControl(root, root.viewIdResourceName ?: "", text)) return root
        for (i in 0 until root.childCount) {
            findSendControl(root.getChild(i))?.let { return it }
        }
        return null
    }

    /** The other person's bubble: on the opposite side from mine and not full-width. */
    private fun isIncomingBubble(b: Bubble, width: Int): Boolean {
        val w = width.toFloat()
        if ((b.right - b.left) / w >= 0.84f) return false
        // v0.29: a real incoming bubble is pinned to its side (next to the avatar).
        // Yoki's grey system cards float in the middle, so they fail this edge test.
        return if (SettingsStore.myMessagesOnLeft(this)) {
            b.centerX > 0.45f * w && b.right <= 0.93f * w && b.right >= 0.78f * w
        } else {
            b.centerX < 0.55f * w && b.left >= 0.07f * w && b.left <= 0.22f * w
        }
    }

    private fun isOwnBubble(bubble: Bubble, width: Int): Boolean {
        val id = bubble.viewId.lowercase()
        if (id.contains("outgoing") || id.contains("sent") || id.contains("mine") || id.contains("me_")) return true
        if (id.contains("incoming") || id.contains("received") || id.contains("other")) return false
        val ratio = bubble.centerX / width.toFloat()
        // Ambiguous middle bubbles are treated as NOT own, so we never
        // silently skip a real incoming message — manual mode still guards sending.
        if (ratio in 0.45f..0.55f) return false
        val ownOnLeft = SettingsStore.myMessagesOnLeft(this)
        return if (ownOnLeft) ratio < 0.5f else ratio > 0.5f
    }

    override fun onInterrupt() = Unit
}

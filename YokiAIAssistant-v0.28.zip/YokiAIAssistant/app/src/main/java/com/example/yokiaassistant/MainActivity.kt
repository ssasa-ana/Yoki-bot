package com.example.yokiaassistant

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val swMonitor = findViewById<Switch>(R.id.swMonitor)
        val rbManual = findViewById<RadioButton>(R.id.rbManual)
        val rbAuto = findViewById<RadioButton>(R.id.rbAuto)
        val rbOff = findViewById<RadioButton>(R.id.rbOff)
        val swDraftMode = findViewById<Switch>(R.id.swDraftMode)
        val rbGemini = findViewById<RadioButton>(R.id.rbGemini)
        val rbOpenAi = findViewById<RadioButton>(R.id.rbOpenAi)
        val etApiKey = findViewById<EditText>(R.id.etApiKey)
        val etModel = findViewById<EditText>(R.id.etModel)
        val etBaseUrl = findViewById<EditText>(R.id.etOpenAiBaseUrl)
        val etSystemPrompt = findViewById<EditText>(R.id.etSystemPrompt)
        val etFallback = findViewById<EditText>(R.id.etFallbackReply)
        val etCustomReplies = findViewById<EditText>(R.id.etCustomReplies)
        val rulesContainer = findViewById<LinearLayout>(R.id.rulesContainer)
        findViewById<Button>(R.id.btnAddRule).setOnClickListener {
            addRuleRow(rulesContainer, "", "")
        }
        val swFallback = findViewById<Switch>(R.id.swFallback)
        val swMyOnLeft = findViewById<Switch>(R.id.swMyOnLeft)
        val swAutoOpen = findViewById<Switch>(R.id.swAutoOpen)
        val etCooldown = findViewById<EditText>(R.id.etCooldown)
        val etMaxPerHour = findViewById<EditText>(R.id.etMaxPerHour)
        val tvStatus = findViewById<TextView>(R.id.tvStatus)
        val tvLog = findViewById<TextView>(R.id.tvLog)

        loadSettings(swMonitor, rbManual, rbAuto, rbOff, swDraftMode, rbGemini, rbOpenAi, etApiKey, etModel,
            etBaseUrl, etSystemPrompt, etFallback, etCustomReplies, swFallback, swMyOnLeft, swAutoOpen, etCooldown, etMaxPerHour)
        refreshStatus(tvStatus)
        tvLog.text = LogStore.readLast(this)

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val prefs = SettingsStore.prefs(this)
            val mode = when {
                rbAuto.isChecked -> "auto"
                rbOff.isChecked -> "off"
                else -> "manual"
            }
            val provider = if (rbOpenAi.isChecked) "openai" else "gemini"
            prefs.edit()
                .putBoolean(SettingsStore.KEY_MONITOR, swMonitor.isChecked)
                .putString(SettingsStore.KEY_MODE, mode)
                .putBoolean(SettingsStore.KEY_DRAFT_MODE, swDraftMode.isChecked)
                .putString(SettingsStore.KEY_PROVIDER, provider)
                .putString(SettingsStore.KEY_MODEL, etModel.text.toString().trim())
                .putString(SettingsStore.KEY_BASE_URL, etBaseUrl.text.toString().trim())
                .putString(SettingsStore.KEY_SYSTEM_PROMPT, etSystemPrompt.text.toString())
                .putString(SettingsStore.KEY_FALLBACK, etFallback.text.toString())
                .putString(SettingsStore.KEY_CUSTOM_REPLIES, etCustomReplies.text.toString())
                .putString(SettingsStore.KEY_KEYWORD_RULES, collectRules(rulesContainer))
                .putBoolean(SettingsStore.KEY_USE_FALLBACK, swFallback.isChecked)
                .putBoolean(SettingsStore.KEY_MY_ON_LEFT, swMyOnLeft.isChecked)
                .putBoolean(SettingsStore.KEY_AUTO_OPEN_NOTIF, swAutoOpen.isChecked)
                .putInt(SettingsStore.KEY_COOLDOWN, etCooldown.text.toString().toIntOrNull() ?: 5)
                .putInt(SettingsStore.KEY_MAX_PER_HOUR, etMaxPerHour.text.toString().toIntOrNull() ?: 20)
                .apply()
            SettingsStore.setApiKey(this, etApiKey.text.toString().trim())
            Toast.makeText(this, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
            refreshStatus(tvStatus)
            LogStore.append(this, "تم حفظ الإعدادات (الوضع: $mode، المزود: $provider)")
        }

        findViewById<Button>(R.id.btnTestAi).setOnClickListener {
            if (SettingsStore.getApiKey(this).isBlank()) {
                Toast.makeText(this, "أدخل مفتاح API أولاً واحفظه", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "جارٍ اختبار الذكاء…", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val raw = AiClient.generateReply(this@MainActivity, listOf("أهلاً، عامل إيه؟"), "أهلاً، عامل إيه؟")
                val reply = raw?.let { SettingsStore.ensureTransparent(it) }
                runOnUiThread {
                    if (reply.isNullOrBlank()) {
                        Toast.makeText(this@MainActivity, "فشل الاختبار: ${AiClient.lastError.take(150)}", Toast.LENGTH_LONG).show()
                        LogStore.append(this@MainActivity, "اختبار الذكاء فشل: ${AiClient.lastError}")
                    } else {
                        Toast.makeText(this@MainActivity, "الرد التجريبي: $reply", Toast.LENGTH_LONG).show()
                        LogStore.append(this@MainActivity, "اختبار الذكاء نجح")
                    }
                }
            }
        }

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnNotificationAccess).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "افتح إعدادات الإشعارات يدوياً وفعّل Yoki AI Assistant", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "افتح إعدادات البطارية يدوياً للتطبيق", Toast.LENGTH_LONG).show()
            }
        }

        findViewById<Button>(R.id.btnRefreshLog).setOnClickListener {
            tvLog.text = LogStore.readLast(this)
            refreshStatus(tvStatus)
        }

        findViewById<Button>(R.id.btnClearLog).setOnClickListener {
            LogStore.clear(this)
            tvLog.text = LogStore.readLast(this)
            Toast.makeText(this, "تم مسح السجل", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSettings(
        swMonitor: Switch, rbManual: RadioButton, rbAuto: RadioButton, rbOff: RadioButton,
        swDraftMode: Switch,
        rbGemini: RadioButton, rbOpenAi: RadioButton, etApiKey: EditText, etModel: EditText,
        etBaseUrl: EditText, etSystemPrompt: EditText, etFallback: EditText, etCustomReplies: EditText,
        swFallback: Switch, swMyOnLeft: Switch, swAutoOpen: Switch, etCooldown: EditText, etMaxPerHour: EditText
    ) {
        val prefs = SettingsStore.prefs(this)
        swMonitor.isChecked = SettingsStore.isMonitorEnabled(this)
        when (SettingsStore.replyMode(this)) {
            "auto" -> rbAuto.isChecked = true
            "off" -> rbOff.isChecked = true
            else -> rbManual.isChecked = true
        }
        swDraftMode.isChecked = SettingsStore.draftMode(this)
        if (SettingsStore.provider(this) == "openai") rbOpenAi.isChecked = true else rbGemini.isChecked = true
        etApiKey.setText(SettingsStore.getApiKey(this))
        etModel.setText(prefs.getString(SettingsStore.KEY_MODEL, ""))
        etModel.hint = "الموديل: ${SettingsStore.model(this)}"
        etBaseUrl.setText(prefs.getString(SettingsStore.KEY_BASE_URL, ""))
        etSystemPrompt.setText(prefs.getString(SettingsStore.KEY_SYSTEM_PROMPT, ""))
        etFallback.setText(SettingsStore.fallbackReply(this))
        etCustomReplies.setText(SettingsStore.customRepliesText(this))
        loadRules(findViewById<LinearLayout>(R.id.rulesContainer), SettingsStore.keywordRulesText(this))
        swFallback.isChecked = SettingsStore.useFallback(this)
        swMyOnLeft.isChecked = SettingsStore.myMessagesOnLeft(this)
        swAutoOpen.isChecked = SettingsStore.autoOpenNotifications(this)
        etCooldown.setText(SettingsStore.cooldownSeconds(this).toString())
        etMaxPerHour.setText(SettingsStore.maxPerHour(this).toString())
    }

    // ---- v0.15: keyword rules as rows (what they write -> what I reply) ----

    private fun addRuleRow(container: LinearLayout, keyword: String, reply: String) {
        val pad = (12 * resources.displayMetrics.density).toInt()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setBackgroundColor(Color.WHITE)
        row.setPadding(pad, pad, pad, pad)
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = pad
        row.layoutParams = lp

        val etKey = EditText(this)
        etKey.hint = "لو الشخص كتب… (كلمة، أو أكتر بفاصلة ،)"
        etKey.setText(keyword)
        etKey.tag = "k"

        val etRep = EditText(this)
        etRep.hint = "رد عليه بـ…"
        etRep.setText(reply)
        etRep.tag = "r"

        val btnDel = Button(this)
        btnDel.text = "حذف القاعدة"
        btnDel.setOnClickListener { container.removeView(row) }

        row.addView(etKey)
        row.addView(etRep)
        row.addView(btnDel)
        container.addView(row)
    }

    private fun collectRules(container: LinearLayout): String {
        val sb = StringBuilder()
        for (i in 0 until container.childCount) {
            val row = container.getChildAt(i) as? LinearLayout ?: continue
            val k = row.findViewWithTag<EditText>("k")?.text?.toString().orEmpty()
                .replace("=", "").replace("\n", " ").trim()
            val r = row.findViewWithTag<EditText>("r")?.text?.toString().orEmpty()
                .replace("\n", " ").trim()
            if (k.isEmpty() || r.isEmpty()) continue
            sb.append(k).append('=').append(r).append('\n')
        }
        return sb.toString().trimEnd()
    }

    private fun loadRules(container: LinearLayout, text: String) {
        container.removeAllViews()
        for (line in text.lines()) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            addRuleRow(container, line.substring(0, i).trim(), line.substring(i + 1).trim())
        }
        if (container.childCount == 0) addRuleRow(container, "", "")
    }

    private fun refreshStatus(tvStatus: TextView) {
        val enabledServices = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val serviceOn = enabledServices.contains("com.example.yokiaassistant/.YokiAccessibilityService")
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val batteryOk = pm.isIgnoringBatteryOptimizations(packageName)
        tvStatus.text = buildString {
            append("الخدمة: ").append(if (serviceOn) "مفعّلة ✓" else "غير مفعّلة — افتح إعدادات إمكانية الوصول")
            append("\nالمراقبة: ").append(if (SettingsStore.isMonitorEnabled(this@MainActivity)) "تعمل" else "متوقفة")
            append("\nالوضع: ").append(SettingsStore.replyMode(this@MainActivity))
            append("\nوضع المسودة: ").append(if (SettingsStore.draftMode(this@MainActivity)) "شغال — يكتب بس، وانت تدوس إرسال" else "مطفي")
            append("\nتجاهل تحسين البطارية: ").append(if (batteryOk) "نعم" else "لا — فعّلها من الزر بالأسفل")
        }
    }

    override fun onResume() {
        super.onResume()
        findViewById<TextView>(R.id.tvStatus)?.let { refreshStatus(it) }
    }
}

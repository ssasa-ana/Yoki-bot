package com.example.yokiaassistant

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Minimal AI client, no extra JSON library (org.json is built in).
 * Gemini: POST .../v1beta/models/{model}:generateContent?key=...
 * OpenAI-compatible: POST {baseUrl}/chat/completions with Bearer key.
 * Runs on Dispatchers.IO with a 30s timeout. Returns null on any failure
 * so the caller can fall back or stay silent instead of sending garbage.
 */
object AiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    /** Last failure reason (HTTP code + message), shown by the "test AI" button. */
    @Volatile
    var lastError: String = ""

    suspend fun generateReply(
        context: Context,
        history: List<String>,
        incoming: String
    ): String? = withContext(Dispatchers.IO) {
        val apiKey = SettingsStore.getApiKey(context)
        if (apiKey.isBlank()) return@withContext null
        val system = SettingsStore.systemPrompt(context)
        val prompt = buildString {
            append(system)
            append("\n\nآخر رسائل المحادثة:\n")
            history.takeLast(5).forEach { append("- ").append(it).append("\n") }
            append("\nآخر رسالة واردة: ").append(incoming)
            append("\n\nاكتب رداً قصيراً بصيغة البوت في سطر أو سطرين فقط، بدون شرح، ولا تتظاهر أنك صاحب الحساب.")
        }
        try {
            val raw = if (SettingsStore.provider(context) == "openai") {
                callOpenAi(apiKey, SettingsStore.model(context), SettingsStore.baseUrl(context), system, prompt)
            } else {
                callGemini(apiKey, SettingsStore.model(context), prompt)
            }
            raw?.trim()?.trim('"', ' ', '\n')?.takeIf { it.isNotBlank() && it.length <= 500 }
        } catch (e: Exception) {
            lastError = "${e.javaClass.simpleName}: ${e.message.orEmpty().take(120)}"
            null
        }
    }

    private fun callGemini(apiKey: String, model: String, prompt: String): String? {
        // v0.28: gemini-2.0-flash was retired by Google. If the chosen model is gone
        // (404/400), fall back to the always-current alias.
        val models = listOf(model, "gemini-flash-latest").distinct()
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            }))
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                // "thinking" models spend tokens before answering; 200 left nothing for the reply.
                put("maxOutputTokens", 1024)
            })
        }.toString()
        for (m in models) {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=$apiKey"
            val request = Request.Builder().url(url)
                .header("x-goog-api-key", apiKey)
                .post(body.toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                val text = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    lastError = "Gemini $m HTTP ${response.code}: ${text.take(160)}"
                    // 404 / 400 → try the next model; anything else (bad key, quota) → stop.
                    if (response.code != 404 && response.code != 400) return null
                    return@use
                }
                val parts = JSONObject(text).optJSONArray("candidates")
                    ?.optJSONObject(0)?.optJSONObject("content")
                    ?.optJSONArray("parts")
                if (parts != null) {
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) {
                        val p = parts.optJSONObject(i) ?: continue
                        if (p.optBoolean("thought", false)) continue
                        sb.append(p.optString("text"))
                    }
                    if (sb.isNotBlank()) return sb.toString()
                }
                lastError = "Gemini $m: رد فاضي"
            }
        }
        return null
    }

    private fun callOpenAi(apiKey: String, model: String, baseUrl: String, system: String, prompt: String): String? {
        val url = baseUrl.trimEnd('/') + "/chat/completions"
        val body = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", system))
                put(JSONObject().put("role", "user").put("content", prompt))
            })
            put("temperature", 0.7)
            put("max_tokens", 200)
        }.toString()
        val request = Request.Builder().url(url)
            .header("Authorization", "Bearer $apiKey")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                lastError = "OpenAI HTTP ${response.code}: ${text.take(160)}"
                return null
            }
            val json = JSONObject(text)
            return json.optJSONArray("choices")
                ?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
        }
    }
}

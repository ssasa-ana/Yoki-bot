package com.example.yokiaassistant

/** Yoki system / promo messages — never worth opening or answering. */
internal fun isYokiSystemText(context: android.content.Context, text: String): Boolean {
    val t = text.trim()
    if (SettingsStore.matchesIgnoreWord(context, t)) return true
    return t.contains("انضم إلى Yoki") ||
        t.contains("صديق جديد") ||
        t.contains("مبروك على وصولك") ||
        t.contains("فتح الدردشة الصوتية") ||
        t.contains("امتياز المكالمة") ||
        t.contains("تعال وجربها") ||
        t == "اتصل الآن" ||
        t == "جربه الآن" ||
        t == "جريه الان" ||
        t.contains("مستوى علاقتك") ||
        t.contains("مستوى الحميمية") ||
        t.contains("الألبومات الخاصة") ||
        t.contains("الذكريات المميزة") ||
        t.contains("فتح الرسائل الصوتية") ||
        t.contains("فتح امتياز") ||
        t.contains("للحصول على الماس") ||
        t.contains("زوجان جيدان") ||
        t.contains("دعنا نتحدث") ||
        t.contains("فائز") ||
    t.contains("متابعتك") ||
    t.contains("تابعتك") ||
    t.contains("تابعني") ||
    t.contains("لنصبح أصدقاء") ||
    t.contains("لنصبح اصدقاء") ||
    t.contains("هيا نتحدث") ||
    t.contains("تابعك") ||
    t.contains("يتابعك") ||
        t.contains("مبروك") && t.contains("الماس") ||
        t.contains("هدية") && t.contains("استلم") ||
        t.startsWith("{image}") ||
        (t.contains("New") && t.contains("انضم"))
}


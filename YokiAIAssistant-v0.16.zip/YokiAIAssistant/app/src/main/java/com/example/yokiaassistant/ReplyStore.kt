package com.example.yokiaassistant

import android.content.Context

/**
 * Anti-spam guards: reply once per incoming message, respect the
 * cooldown between replies, and cap replies per hour.
 * State lives in SharedPreferences so it survives restarts.
 */
object ReplyStore {
    private const val PREFS = "yoki_reply_state"
    private const val KEY_LAST_HASH = "last_hash"
    private const val KEY_LAST_AT = "last_reply_at"
    private const val KEY_HOUR_START = "hour_start"
    private const val KEY_HOUR_COUNT = "hour_count"

    fun shouldReply(context: Context, hash: Int, now: Long = System.currentTimeMillis()): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val lastAt = prefs.getLong(KEY_LAST_AT, 0L)
        // v0.11: same text only blocks for 2 minutes (same chat re-processing);
        // two different people saying "هاي" must both get an answer.
        if (prefs.getInt(KEY_LAST_HASH, 0) == hash && now - lastAt < 120_000L) return false
        if (now - lastAt < SettingsStore.cooldownSeconds(context) * 1000L) return false
        val hourStart = prefs.getLong(KEY_HOUR_START, 0L)
        val count = if (now - hourStart < 3600_000L) prefs.getInt(KEY_HOUR_COUNT, 0) else 0
        if (count >= SettingsStore.maxPerHour(context)) return false
        return true
    }

    fun markReplied(context: Context, hash: Int, now: Long = System.currentTimeMillis()) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val hourStart = prefs.getLong(KEY_HOUR_START, 0L)
        val count = if (now - hourStart < 3600_000L) prefs.getInt(KEY_HOUR_COUNT, 0) else 0
        prefs.edit()
            .putInt(KEY_LAST_HASH, hash)
            .putLong(KEY_LAST_AT, now)
            .putLong(KEY_HOUR_START, if (count == 0) now else hourStart)
            .putInt(KEY_HOUR_COUNT, count + 1)
            .apply()
    }
}
